
let open = false;

let btn = document.getElementById('btn');
let donate = document.getElementById("donate");
let help = document.getElementById("help");
let inputWindow = document.getElementsByClassName("input_wrapper")[0];
let otpWindow = document.getElementsByClassName("otp_wrapper")[0];
let otp = document.getElementById('otp');
let count = document.getElementById("count");
let id_setting = document.querySelector('input[type="checkbox"]');
let id_text = document.getElementsByName("id")[0];



btn.addEventListener("click",openWindow);
donate.addEventListener("click",donateWindow);
help.addEventListener("click",helpWindow);
otpWindow.addEventListener("click",copyOTP);
id_setting.addEventListener("change",id_setting_handler);
id_text.addEventListener("change",id_text_handler);

function id_setting_handler()
{
    chrome.storage.sync.set({id_setting: id_setting.checked});
}

function id_text_handler()
{
    chrome.storage.sync.set({id: id_text.value});
}

function updateOTP() {
    chrome.storage.sync.get(function (data) {
        if (data.key != undefined && data.key != "" )
        {
            otpWindow.style.height = "auto";
            let password = getOtp(data.key);
            otp.innerText = password;
            let epoch = Math.round(new Date().getTime() / 1000.0);
            count.innerText = 30 - (epoch % 30) ;
            
        }
        else
        {
            otpWindow.style.height = "0px";
        }
    });
}

function copyOTP() {
    chrome.storage.sync.get(function (data) {
        if (data.key != undefined && data.key != "" )
        {
            let password = getOtp(data.key);
            copyToClipboard(password);        
            var toast = document.createElement('div');
            toast.style = "opacity: 0; position: absolute; bottom: 10px; width: 100%; text-align: center; color: white; font-size: 16px; font-weight: bold;";
            toast.innerText = "OTP has been copied to clipboard!";
            document.body.appendChild(toast);
            var intervalID = null;
            var level = 0;
            intervalID = setInterval( () => {level = changeOpacity(toast,level,intervalID)},50);
            
        }
    });
}

function changeOpacity(target,level,intervalID)
{
    if (level < 1)
    {
        target.style.opacity = level;
        return level + 0.15;
    }
    else if (level < 2)
    {
        target.style.opacity = 1;
    }
    else if (level < 3)
    {
        target.style.opacity = 3-level;
    }
    else
    {
        target.remove();
        clearInterval(intervalID);
    }

    return level + 0.1;

}

function openWindow()
{
    if (open)
    {
        if (document.getElementsByName("key")[0].value != "")
        {
            chrome.storage.sync.set({key: document.getElementsByName("key")[0].value});
        }
        inputWindow.style.height = "0px";
        btn.innerText = "키 입력";
        
    }
    else
    {
        inputWindow.style.height = "auto";
        btn.innerText = "저장";
        document.getElementsByName("key")[0].focus();
    }
    
    open = !open;
}


function donateWindow()
{
    window.open("https://techprovider2021.github.io/kaistotp/donate.html");
}


function helpWindow()
{
    window.open("https://techprovider2021.github.io/kaistotp/help.html");
}

setInterval( updateOTP,500);

chrome.storage.sync.get(function (data) {
    if (data.id != undefined && data.id != null && data.id != "")
    {   
        id_text.value = data.id;
    }
    id_setting.checked = data.id_setting;
});