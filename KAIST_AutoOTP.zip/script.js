let current_password;
let key;
html = "window.history.pushState = history.pushState = ( f => function pushState(){ var ret = f.apply(this, arguments); window.dispatchEvent(new Event('locationchange')); return ret;})(history.pushState);";
var headID = document.getElementsByTagName("head")[0];         
var newScript = document.createElement('script');
newScript.type = 'text/javascript';
newScript.innerHTML = html;
headID.appendChild(newScript);

function wait(delay) 
{
    if (window.location.href.startsWith("https://iam2.kaist.ac.kr/#/userLogin") || window.location.href.startsWith("https://iam2.kaist.ac.kr/#/commonLogin"))
    {
        try
        {
            chrome.storage.sync.get(function (data) {
                let id = data.id;
                if (id != undefined && id != null && id != "" && data.id_setting)
                {
                    target = document.querySelector('input[id="IdInput"]');
                    forcedInput(target,id);
                    document.querySelectorAll('input[type="submit"]')[1].click();
                    document.querySelector('input[type="password"]').select();
                } 
            });
        }
        catch
        {
            setTimeout(()=>wait(delay),delay);
        }
        
    }
    else if (window.location.href.startsWith("https://iam2.kaist.ac.kr/#/checkOtp"))
    {
        if (document.body.innerHTML.includes("Google OTP"))
        {

            try
            {
                document.getElementsByTagName("fieldset")[0].firstChild.children[1].firstChild.click();
                chrome.storage.sync.get(function (data) {
                    let password = getOtp(data.key);
                    current_password = password;
                    key = data.key;

                    let target = document.querySelector('input[type="password"]');
                    forcedInput(target,password);
                    document.getElementsByTagName("fieldset")[0].firstChild.children[4].firstChild.click();
                });
                setTimeout(()=>wait(500),500);
                //setTimeout(()=>refresh(1000),1000);
            }
            catch
            {
                setTimeout(()=>wait(delay),delay);
            }
            
        }
        else
        {
            setTimeout(()=>wait(delay),delay);
        }
        
    }
};

function forcedInput(target,text)
{
    if (text != undefined && text != null && target != null)
    {
        target.value = text;
        var e = document.createEvent('HTMLEvents');
        e.keyCode = 13;
        e.initEvent('input', false, true);
        target.dispatchEvent(e);
    }
} 

function refresh(delay)
{
    if (window.location.href.startsWith("https://iam2.kaist.ac.kr/#/checkOtp"))
    {
        let password = getOtp(key);
        if (current_password != password)
        {
            current_password = password;
            copyToClipboard(password);
            alert("새로운 OTP가 클립보드에 복사되었습니다.\r\n"+"New OTP has been copied to clipboard.");
            copyToClipboard(password);

        }
        setTimeout(()=>refresh(delay),delay);
    }
}


window.addEventListener('locationchange', function(){
    wait(200);
});


wait(200);